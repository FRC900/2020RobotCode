/* License: Apache 2.0. See LICENSE file in root directory.
   Copyright(c) 2017 Intel Corporation. All Rights Reserved. */

#pragma once

#define D4XX_RECOMMENDED_FIRMWARE_VERSION "5.11.11.100"
#define SR3XX_RECOMMENDED_FIRMWARE_VERSION "3.26.1.0"
#define D4XX_RC_FIRMWARE_VERSION "5.11.14.0"